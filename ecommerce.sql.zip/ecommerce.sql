--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL,
  `brand` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `brand`) VALUES
(1, 'Apple'),
(2, 'Lenovo'),
(5, 'Dell'),
(6, 'HPss');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `cus_cart_id` int(11) NOT NULL,
  `items` text NOT NULL,
  `expire_date` datetime NOT NULL,
  `paid` tinyint(4) NOT NULL DEFAULT '0',
  `cart_ship_id` int(11) NOT NULL,
  `cart_pay_id` int(11) NOT NULL,
  `cart_bill_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `parent_category` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `parent_category`) VALUES
(1, 'ELECTRONICS', 0),
(2, 'APPLIANCES', 0),
(4, 'Laptops', 1),
(5, 'Desktops', 1),
(9, 'Shirts', 8),
(11, 'Washing Machine', 2),
(12, 'Refrigerators', 2),
(13, 'MEN', 0),
(14, 'Shirts', 13),
(16, 'Mobiles', 1),
(18, 'Trousers', 13);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(10) NOT NULL,
  `customer_name` text NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_password` varchar(100) NOT NULL,
  `customer_type` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_email`, `customer_password`, `customer_type`) VALUES
(22, 'Manohar Katam', 'manohar@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1),
(24, 'praveen', 'praveen@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 1),
(29, 'karthik', 'karthik@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0),
(30, 'vivek', 'vivek@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1),
(31, 'kranthi', 'kranthi@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_bill`
--

CREATE TABLE `customer_bill` (
  `cust_bill_id` int(10) NOT NULL,
  `cust_id` int(10) NOT NULL,
  `cust_billname` text NOT NULL,
  `cust_billadd` text NOT NULL,
  `cust_billcity` text NOT NULL,
  `cust_billstate` text NOT NULL,
  `cust_billzipcode` varchar(10) NOT NULL,
  `cust_billmobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_bill`
--

INSERT INTO `customer_bill` (`cust_bill_id`, `cust_id`, `cust_billname`, `cust_billadd`, `cust_billcity`, `cust_billstate`, `cust_billzipcode`, `cust_billmobile`) VALUES
(22, 22, 'Manohar Katam', '7575 Frankford Rd, Apt 2923', 'DALLAS', 'Texas', '75252', '6822569202'),
(23, 23, 'Manohar Katam', '7575 Frankford Rd, Apt 2923', 'DALLAS', 'Texas', '75252', '6822569202'),
(29, 29, 'Manohar Katam', 'H.No: 2-108/4/44, B.L Nagar Colony, Boduppal', 'Hyderabad', 'California', '500092', '9567183369'),
(31, 31, 'Kranthi Kumar Katam', '121', 'DALLAS', 'Texas', '75252', '6822569202');

-- --------------------------------------------------------

--
-- Table structure for table `customer_details`
--

CREATE TABLE `customer_details` (
  `cus_detail_id` int(10) NOT NULL,
  `cus_id` int(10) NOT NULL,
  `cus_fullname` text NOT NULL,
  `cus_address` varchar(255) NOT NULL,
  `cus_city` text NOT NULL,
  `cus_state` text NOT NULL,
  `cus_zipcode` varchar(10) NOT NULL,
  `cus_mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_details`
--

INSERT INTO `customer_details` (`cus_detail_id`, `cus_id`, `cus_fullname`, `cus_address`, `cus_city`, `cus_state`, `cus_zipcode`, `cus_mobile`) VALUES
(22, 31, 'Manohar Katam', '7575 Frankford Rd Apt 2923', 'DALLAS', 'TX', '75252', '6822569202'),
(29, 29, 'Manohar Katam', '7575 Frankford Rd, Apt 2923', 'DALLAS', 'Texas', '75252', '6822569202'),
(32, 31, 'Kranthi', '7575 Frankford Rd, Apt 2923', 'DALLAS', 'CA', '752525', '6822569202');

-- --------------------------------------------------------

--
-- Table structure for table `customer_pay`
--

CREATE TABLE `customer_pay` (
  `c_pay_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  `c_nameOnCard` text NOT NULL,
  `c_card` varchar(20) NOT NULL,
  `c_expiryMonth` varchar(20) NOT NULL,
  `c_expiryYear` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_pay`
--

INSERT INTO `customer_pay` (`c_pay_id`, `c_id`, `c_nameOnCard`, `c_card`, `c_expiryMonth`, `c_expiryYear`) VALUES
(22, 22, 'Manohar Katam', '1234567890123456', '05', '22'),
(29, 29, 'Mano', '1234567890098765', '04', '18'),
(31, 31, 'Kranthi Kumar', '1234567890123456', '02', '20');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_cust_id` int(11) NOT NULL,
  `total_price` double(10,2) NOT NULL,
  `order_date` date NOT NULL,
  `order_ship_id` int(11) NOT NULL,
  `order_pay_id` int(11) NOT NULL,
  `order_bill_id` int(11) NOT NULL,
  `order_status` enum('pending','approved') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_cust_id`, `total_price`, `order_date`, `order_ship_id`, `order_pay_id`, `order_bill_id`, `order_status`) VALUES
(1, 31, 0.00, '2017-03-26', 32, 31, 31, 'approved'),
(2, 31, 1360.35, '2017-03-26', 22, 31, 31, 'approved'),
(3, 31, 2158.84, '2017-03-26', 22, 31, 31, 'approved'),
(4, 31, 0.00, '2017-03-26', 22, 31, 31, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `orders_line`
--

CREATE TABLE `orders_line` (
  `order_lineitem_id` int(11) NOT NULL,
  `order_line_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `extended_price` decimal(10,2) NOT NULL,
  `order_lineitem_ord_id` int(11) NOT NULL,
  `order_lineitem_prdct_id` int(11) NOT NULL,
  `returned` tinyint(4) NOT NULL,
  `canceled` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_line`
--

INSERT INTO `orders_line` (`order_lineitem_id`, `order_line_name`, `quantity`, `price`, `extended_price`, `order_lineitem_ord_id`, `order_lineitem_prdct_id`, `returned`, `canceled`) VALUES
(1, 'Iphone 7 Black 32GB', 2, '799.00', '1732.87', 1, 6, 1, 0),
(2, 'Iphone 7 Black 32GB', 1, '799.00', '863.32', 2, 6, 0, 1),
(3, 'Apple Mac Book Air', 1, '1259.00', '1360.35', 2, 5, 0, 0),
(4, 'Lenovo Ideapad Y500', 2, '999.00', '2158.84', 3, 2, 0, 0),
(5, 'Lenovo Ideapad Y300', 1, '979.00', '1057.81', 4, 3, 0, 1),
(6, 'Iphone 7 Black 32GB', 1, '799.00', '863.32', 4, 6, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `list_price` decimal(10,2) DEFAULT NULL,
  `brand` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `featured` tinyint(4) NOT NULL DEFAULT '0',
  `sizes` text NOT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `title`, `price`, `list_price`, `brand`, `category`, `image`, `description`, `featured`, `sizes`, `deleted`) VALUES
(1, 'Apple Mac Book Pro', '1459.99', '1499.00', 1, 4, '/ecommerce3/images/product3.jpg', 'This is the New Apple Mac Book Pro 2017 Version with Touch bar', 1, '13 Inch:2', 0),
(2, 'Lenovo Ideapad Y500', '999.00', NULL, 2, 4, '/ecommerce3/images/product2.jpg', 'All New Lenovo Ideapad Y500, 8GB RAM, 1TB HDD, QHD Dispaly', 1, '13 Inch:0', 0),
(3, 'Lenovo Ideapad Y300', '979.00', NULL, 2, 4, '/ecommerce3/images/product2.jpg', 'All New Lenovo Ideapad Y500, 8GB RAM, 1TB HDD, QHD Dispaly', 1, '13 Inch:1', 0),
(4, 'Dell Inspiron', '979.00', '999.00', 2, 4, '/ecommerce3/images/product5.jpg', 'All New Dell Inspiron, 8GB RAM, 1TB HDD, QHD Dispaly', 1, '15 Inch:3', 0),
(5, 'Apple Mac Book Air', '1259.00', '1300.00', 1, 4, '/ecommerce3/images/product3.jpg', 'This is the New Apple Mac Book Pro 2017 Version with Touch bar', 1, '13 Inch:16', 0),
(6, 'Iphone 7 Black 32GB', '799.00', NULL, 1, 16, '/ecommerce3/images/product3.jpg', 'This is the New Iphone 7, 32 GB RAM', 1, '4.7 Inch:14', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shipments`
--

CREATE TABLE `shipments` (
  `shipment_id` int(11) NOT NULL,
  `shipment_lineitem_id` int(11) NOT NULL,
  `shipment_status` enum('','pick','pack','ship') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipments`
--

INSERT INTO `shipments` (`shipment_id`, `shipment_lineitem_id`, `shipment_status`) VALUES
(1, 1, 'ship'),
(2, 2, ''),
(3, 3, 'pack'),
(4, 6, 'ship'),
(5, 4, 'pack');

-- --------------------------------------------------------

--
-- Table structure for table `tasks_returns`
--

CREATE TABLE `tasks_returns` (
  `return_id` int(11) NOT NULL,
  `ret_order_id` int(11) NOT NULL,
  `ret_order_line_id` int(11) NOT NULL,
  `ret_date` date NOT NULL,
  `return_status` enum('RETURN INITIATED','RETURN ACCEPTED','RETURN DECLINED','RETURN RECEIVED') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tasks_returns`
--

INSERT INTO `tasks_returns` (`return_id`, `ret_order_id`, `ret_order_line_id`, `ret_date`, `return_status`) VALUES
(2, 1, 1, '2017-03-26', 'RETURN RECEIVED'),
(3, 4, 6, '2017-03-26', 'RETURN RECEIVED');

-- --------------------------------------------------------

--
-- Table structure for table `tax`
--

CREATE TABLE `tax` (
  `state_id` char(2) NOT NULL,
  `state_tax` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tax`
--

INSERT INTO `tax` (`state_id`, `state_tax`) VALUES
('CA', 8.44),
('CO', 7.44),
('FL', 6.65),
('IL', 8.19),
('IN', 7.00),
('MA', 6.25),
('MI', 6.00),
('NY', 8.48),
('OH', 7.10),
('TX', 8.05);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_bill`
--
ALTER TABLE `customer_bill`
  ADD PRIMARY KEY (`cust_bill_id`);

--
-- Indexes for table `customer_details`
--
ALTER TABLE `customer_details`
  ADD PRIMARY KEY (`cus_detail_id`);

--
-- Indexes for table `customer_pay`
--
ALTER TABLE `customer_pay`
  ADD PRIMARY KEY (`c_pay_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `orders_line`
--
ALTER TABLE `orders_line`
  ADD PRIMARY KEY (`order_lineitem_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `shipments`
--
ALTER TABLE `shipments`
  ADD PRIMARY KEY (`shipment_id`);

--
-- Indexes for table `tasks_returns`
--
ALTER TABLE `tasks_returns`
  ADD PRIMARY KEY (`return_id`);

--
-- Indexes for table `tax`
--
ALTER TABLE `tax`
  ADD PRIMARY KEY (`state_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `customer_bill`
--
ALTER TABLE `customer_bill`
  MODIFY `cust_bill_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `customer_details`
--
ALTER TABLE `customer_details`
  MODIFY `cus_detail_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `customer_pay`
--
ALTER TABLE `customer_pay`
  MODIFY `c_pay_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `orders_line`
--
ALTER TABLE `orders_line`
  MODIFY `order_lineitem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `shipments`
--
ALTER TABLE `shipments`
  MODIFY `shipment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tasks_returns`
--
ALTER TABLE `tasks_returns`
  MODIFY `return_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
